const kip = 'kip is lekker'
console.log(kip);